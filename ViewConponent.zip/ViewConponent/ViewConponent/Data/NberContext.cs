﻿using Microsoft.EntityFrameworkCore;
using ViewConponent.Models;

namespace ViewConponent.Data
{
    public class NberContext : DbContext
    {
        public string conn = "server=localhost;userid=root;database=users;";
        public NberContext(DbContextOptions options) : base(options)
        {
        }
        public DbSet<NBER> users { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
                optionsBuilder.UseMySql(conn, ServerVersion.AutoDetect(conn));
        }
    }
}
