﻿using Microsoft.AspNetCore.Mvc;
using ViewConponent.Data;
using ViewConponent.Models;

namespace ViewConponent.Views.Shared.Components.Nber
{
    public class NberViewComponent : ViewComponent
    {
        private readonly NberContext _context;
        public NberViewComponent(NberContext x)
        {
            _context = x;
        }
        public async Task<IViewComponentResult> InvokeAsync()
        {
            var x = (from i in _context.users select i).ToList();
            return View(x);
        }
    }
}
